"use client";

import * as React from "react";
import { Box, MessageSquare, Zap, Settings, HelpCircle, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface NavItemProps {
  icon: React.ReactNode;
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

function NavItem({ icon, label, isActive, onClick }: NavItemProps) {
  return (
    <TooltipProvider delayDuration={0}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClick}
            className={cn(
              "h-10 w-10 rounded-lg transition-all",
              isActive
                ? "bg-primary/20 text-primary"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
            )}
          >
            {icon}
          </Button>
        </TooltipTrigger>
        <TooltipContent side="right" className="bg-popover text-popover-foreground">
          {label}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function AppSidebar() {
  const [activeNav, setActiveNav] = React.useState("chat");

  return (
    <div className="flex h-full w-16 flex-col items-center border-r border-sidebar-border bg-sidebar py-4">
      {/* Logo */}
      <div className="mb-6">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary/70">
          <Box className="h-5 w-5 text-primary-foreground" />
        </div>
      </div>

      {/* Brand Name */}
      <div className="mb-8 -rotate-90 whitespace-nowrap text-xs font-semibold tracking-wider text-sidebar-foreground/80">
        SUDOCLAW
      </div>

      {/* Navigation */}
      <nav className="flex flex-1 flex-col items-center gap-2">
        <NavItem
          icon={<MessageSquare className="h-5 w-5" />}
          label="聊天"
          isActive={activeNav === "chat"}
          onClick={() => setActiveNav("chat")}
        />
        <NavItem
          icon={<Zap className="h-5 w-5" />}
          label="技能"
          isActive={activeNav === "skills"}
          onClick={() => setActiveNav("skills")}
        />
        <NavItem
          icon={<Settings className="h-5 w-5" />}
          label="设置"
          isActive={activeNav === "settings"}
          onClick={() => setActiveNav("settings")}
        />
      </nav>

      {/* Bottom Actions */}
      <div className="mt-auto flex flex-col items-center gap-2">
        <NavItem icon={<HelpCircle className="h-5 w-5" />} label="帮助" />
        <NavItem icon={<LogOut className="h-5 w-5" />} label="退出" />
        <div className="mt-2">
          <Avatar className="h-9 w-9 border-2 border-sidebar-border">
            <AvatarFallback className="bg-gradient-to-br from-primary to-primary/70 text-xs text-primary-foreground">
              hi
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </div>
  );
}
